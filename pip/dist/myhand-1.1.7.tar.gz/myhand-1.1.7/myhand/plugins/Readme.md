This directory contains myHand plugins.
myHand plugins are Python files to be executed when myHand starts.