This directory contains taskWiz plugins.
taskWiz plugins are Python files to be executed when taskWiz starts.