"""
TaskWiz Bot Plugin - instructions

add predefined instructions
"""

from taskwiz import config

config.predefinedInstructions["Write a Summary"] = "Write a summary"

config.predefinedInstructions["Explain its Meaning"] = "Explain its meaning to me."