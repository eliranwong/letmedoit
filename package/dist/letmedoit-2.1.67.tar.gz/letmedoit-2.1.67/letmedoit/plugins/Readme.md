This directory contains letMeDoIt plugins.
letMeDoIt plugins are Python files to be executed when letMeDoIt starts.